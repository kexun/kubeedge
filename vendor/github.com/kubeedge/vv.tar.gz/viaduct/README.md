# Viaduct
The viaduct is a bridge that carries a road across a valley，the valley is the gap between cloud and edge and the bridge is the connection across the gap
# Overview
Viaduct use the protobuf3.0 to serialize message that defined in beehive and provide  
apis for connection and message operations

By now, Viaduct has supported websocket(gorilla websocket) and quic(quic-go) as the basic transport protocol

# TODO
- add ut
- add e2e testing
- add benchmark
