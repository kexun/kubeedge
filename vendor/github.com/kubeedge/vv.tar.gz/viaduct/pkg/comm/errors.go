package comm

const (
	StatusCodeNoError = 0

	StatusCodeFreeStream = 1
)
